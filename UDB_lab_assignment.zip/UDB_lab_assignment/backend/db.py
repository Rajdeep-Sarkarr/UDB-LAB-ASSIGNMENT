from pymongo import MongoClient, ASCENDING

client = MongoClient("mongodb://localhost:27017/")
db = client["socialmedia"]

users    = db["users"]
posts    = db["posts"]
comments = db["comments"]
likes    = db["likes"]

users.create_index([("username", ASCENDING)], unique=True)
users.create_index([("email", ASCENDING)], unique=True)

posts.create_index([("user_id", ASCENDING)])

comments.create_index([("post_id", ASCENDING)])
comments.create_index([("user_id", ASCENDING)])

likes.create_index([("post_id", ASCENDING), ("user_id", ASCENDING)], unique=True)

print("DB connected and indexes ready")