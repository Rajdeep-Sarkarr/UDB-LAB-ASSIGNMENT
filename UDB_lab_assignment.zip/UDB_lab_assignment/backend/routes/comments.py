from flask import Blueprint, request, jsonify
from db import comments, users
from bson import ObjectId
from datetime import datetime

comments_bp = Blueprint("comments", __name__)

def fmt(doc):
    doc["_id"]     = str(doc["_id"])
    doc["post_id"] = str(doc["post_id"])
    doc["user_id"] = str(doc["user_id"])
    return doc

@comments_bp.route("/", methods=["POST"])
def create_comment():
    data = request.json
    data["post_id"]    = ObjectId(data["post_id"])
    data["user_id"]    = ObjectId(data["user_id"])
    data["created_at"] = datetime.utcnow()
    result = comments.insert_one(data)
    return jsonify({"id": str(result.inserted_id)}), 201

@comments_bp.route("/post/<post_id>", methods=["GET"])
def get_comments(post_id):
    result = []
    for c in comments.find({"post_id": ObjectId(post_id)}):
        c = fmt(c)
        user = users.find_one({"_id": ObjectId(c["user_id"])})
        c["username"] = user["username"] if user else "Unknown"
        result.append(c)
    return jsonify(result)

@comments_bp.route("/<id>", methods=["DELETE"])
def delete_comment(id):
    comments.delete_one({"_id": ObjectId(id)})
    return jsonify({"message": "Deleted"})