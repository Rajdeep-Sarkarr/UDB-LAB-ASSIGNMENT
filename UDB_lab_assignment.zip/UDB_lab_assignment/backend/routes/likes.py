from flask import Blueprint, request, jsonify
from db import likes
from bson import ObjectId
from datetime import datetime

likes_bp = Blueprint("likes", __name__)

@likes_bp.route("/", methods=["POST"])
def like_post():
    data = request.json
    try:
        likes.insert_one({
            "post_id":    ObjectId(data["post_id"]),
            "user_id":    ObjectId(data["user_id"]),
            "created_at": datetime.utcnow()
        })
        return jsonify({"message": "Liked"}), 201
    except Exception:
        return jsonify({"error": "Already liked"}), 400

@likes_bp.route("/", methods=["DELETE"])
def unlike_post():
    data = request.json
    likes.delete_one({
        "post_id": ObjectId(data["post_id"]),
        "user_id": ObjectId(data["user_id"])
    })
    return jsonify({"message": "Unliked"})

@likes_bp.route("/count/<post_id>", methods=["GET"])
def like_count(post_id):
    count = likes.count_documents({"post_id": ObjectId(post_id)})
    return jsonify({"count": count})